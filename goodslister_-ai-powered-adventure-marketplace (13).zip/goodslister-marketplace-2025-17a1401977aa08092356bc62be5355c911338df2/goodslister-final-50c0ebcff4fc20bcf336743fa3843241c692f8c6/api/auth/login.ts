import { sql } from '@vercel/postgres';
import type { VercelRequest, VercelResponse } from '@vercel/node';
import crypto from 'crypto';

// Inline helpers to avoid module resolution issues
function hashPassword(password: string): { salt: string; hash: string } {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto
    .pbkdf2Sync(password, salt, 1000, 64, 'sha512')
    .toString('hex');
  return { salt, hash };
}

function verifyPassword(password: string, salt: string, storedHash: string): boolean {
  const hash = crypto
    .pbkdf2Sync(password, salt, 1000, 64, 'sha512')
    .toString('hex');
  return hash === storedHash;
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { email: rawEmail, password } = req.body;

  if (!rawEmail || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
  }

  const email = rawEmail.toLowerCase().trim();

  try {
    // 1. Fetch User
    let userResult = await sql`SELECT * FROM users WHERE LOWER(email) = ${email}`;
    
    if (userResult.rows.length === 0) {
        // ADMIN AUTO-RECOVERY: If it's Luciano, create the account if it's missing
        if (email === 'lucianoreverberi@gmail.com') {
             const id = `admin-luciano-${Date.now()}`;
             const { salt, hash } = hashPassword(password);
             try {
                await sql`
                    INSERT INTO users (id, name, email, registered_date, avatar_url, role, password_hash, password_salt, is_id_verified, is_email_verified)
                    VALUES (${id}, 'Luciano Reverberi', ${email}, CURRENT_DATE, 'https://i.pravatar.cc/150?u=lucianoreverberi', 'SUPER_ADMIN', ${hash}, ${salt}, true, true)
                `;
                userResult = await sql`SELECT * FROM users WHERE id = ${id}`;
             } catch (createErr) {
                 console.error("Admin auto-create failed:", createErr);
                 return res.status(500).json({ error: 'Could not initialize admin account' });
             }
        } else {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
    }

    const user = userResult.rows[0];

    // --- SECURITY & RECOVERY LOGIC ---
    let isValid = false;

    // Helper to safely update password, creating columns if they are missing (Schema Self-Healing)
    const forceUpdatePassword = async (userId: string, pass: string) => {
        const { salt, hash } = hashPassword(pass);
        try {
            await sql`
                UPDATE users 
                SET password_hash = ${hash}, password_salt = ${salt} 
                WHERE id = ${userId}
            `;
        } catch (dbError: any) {
            if (dbError.code === '42703' || dbError.message?.includes('does not exist')) {
                await sql`ALTER TABLE users ADD COLUMN IF NOT EXISTS password_hash TEXT`;
                await sql`ALTER TABLE users ADD COLUMN IF NOT EXISTS password_salt TEXT`;
                await sql`UPDATE users SET password_hash = ${hash}, password_salt = ${salt} WHERE id = ${userId}`;
            }
        }
    };

    // Check 1: Is it a legacy user (no hash)?
    if (!user.password_hash || !user.password_salt) {
        await forceUpdatePassword(user.id, password);
        isValid = true; 
    } else {
        // Check 2: Verify Password
        isValid = verifyPassword(password, user.password_salt, user.password_hash);

        // Check 3: Admin/Demo Recovery (NUCLEAR OPTION)
        if (!isValid) {
            const isRecoveryTarget = email === 'lucianoreverberi@gmail.com' || email === 'carlos.gomez@example.com';
            if (isRecoveryTarget) {
                await forceUpdatePassword(user.id, password);
                isValid = true;
            }
        }
    }

    if (!isValid) {
        return res.status(401).json({ error: 'Incorrect email or password.' });
    }

    // Success! Return user data (sanitized)
    const userData = {
        id: user.id,
        name: user.name,
        email: user.email,
        registeredDate: user.registered_date ? new Date(user.registered_date).toISOString().split('T')[0] : '',
        avatarUrl: user.avatar_url,
        isEmailVerified: user.is_email_verified,
        isPhoneVerified: user.is_phone_verified,
        isIdVerified: user.is_id_verified,
        licenseVerified: user.license_verified,
        averageRating: Number(user.average_rating),
        totalReviews: user.total_reviews,
        favorites: user.favorites || [],
        role: user.role || 'USER',
        homeRegion: user.home_region || 'US'
    };

    return res.status(200).json(userData);

  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({ error: 'Login failed. Please try again.' });
  }
}