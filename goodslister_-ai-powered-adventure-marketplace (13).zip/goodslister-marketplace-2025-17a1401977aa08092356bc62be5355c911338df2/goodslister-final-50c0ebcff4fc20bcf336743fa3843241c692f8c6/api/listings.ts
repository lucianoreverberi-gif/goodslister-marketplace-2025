
// This file is deprecated to reduce the Vercel Serverless Function count (Limit: 12).
// Listing data is now fetched via /api/app-data.ts
export const config = {
  runtime: 'edge',
};
