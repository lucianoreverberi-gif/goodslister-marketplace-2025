
// This file is deprecated to reduce the Vercel Serverless Function count (Limit: 12).
// Functionality is not used by the frontend.
export const config = {
  runtime: 'edge', // Optional: just to mark it valid TS
};
