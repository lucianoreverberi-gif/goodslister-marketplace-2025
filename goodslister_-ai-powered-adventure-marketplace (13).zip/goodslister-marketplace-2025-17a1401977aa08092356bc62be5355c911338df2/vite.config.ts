import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath, URL } from 'url';

export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, '.', '');
    return {
      server: {
        port: 3000,
        host: '0.0.0.0',
      },
      plugins: [react()],
      define: {
        // FIX: Support both API_KEY and GEMINI_API_KEY from environment
        'process.env.API_KEY': JSON.stringify(env.API_KEY || env.GEMINI_API_KEY),
        'process.env.GEMINI_API_KEY': JSON.stringify(env.API_KEY || env.GEMINI_API_KEY)
      },
      resolve: {
        alias: {
          // FIX: Replaced path.resolve(__dirname, '.') with fileURLToPath and URL to fix '__dirname is not defined' error in ESM.
          '@': fileURLToPath(new URL('.', import.meta.url)),
        }
      }
    };
});